#include "..\\Header\\fifo.h"

// // Function to push an element into the FIFO
// template <typename T>
// void FIFO<T>::push(const T &value)
// {
//     if (fifoQueue.size() <= maxCapacity)
//     {
//         fifoQueue.push(value);
//     }
//     else
//     {
//         std::cerr << "Error: Trying to push a value into a full FIFO.\n";
//     }
// }

// // Function to pop an element from the FIFO
// template <typename T>
// void FIFO<T>::pop()
// {
//     if (!isEmpty())
//     {
//         fifoQueue.pop();
//     }
//     else
//     {
//         std::cerr << "Error: Trying to pop from an empty FIFO.\n";
//     }
// }

// // Function to get the front element of the FIFO
// template <typename T>
// T FIFO<T>::front() const
// {
//     if (!isEmpty())
//     {
//         return fifoQueue.front();
//     }
//     else
//     {
//         std::cerr << "Error: Trying to access front of an empty FIFO.\n";
//         return T(); // Return a default-constructed value for error case
//     }
// }

// // Function to check if the FIFO is empty
// template <typename T>
// bool FIFO<T>::isEmpty() const
// {
//     return fifoQueue.empty();
// }

// // Function to get the size of the FIFO
// template <typename T>
// size_t FIFO<T>::size() const
// {
//     return fifoQueue.size();
// }

// // Function to push an element into a specific bank
// template <typename T>
// void BankedFIFO<T>::push(size_t bankIndex, const T &value)
// {
//     if (bankIndex < numBanks)
//     {
//         banks[bankIndex]->push(value);
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to push a series of element into banks starting from bankIndex
// template <typename T>
// void BankedFIFO<T>::push(size_t bankIndexStart, size_t bankIndexEnd, const std::vector<T> &values)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && bankIndexEnd - bankIndexStart == values.size())
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
//         {
//             banks[i]->push(values[i - bankIndexStart]);
//         }
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to push a series of element into banks starting from bankIndex with stride
// template <typename T>
// void BankedFIFO<T>::push(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, const std::vector<T> &values)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && ((size_t)(bankIndexEnd - bankIndexStart) / stride) == values.size())
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
//         {
//             banks[i]->push(values[(i - bankIndexStart) / stride]);
//         }
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to pop an element from a specific bank
// template <typename T>
// void BankedFIFO<T>::pop(size_t bankIndex)
// {
//     if (bankIndex < numBanks)
//     {
//         banks[bankIndex]->pop();
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to pop a series of element from banks starting from bankIndex
// template <typename T>
// void BankedFIFO<T>::pop(size_t bankIndexStart, size_t bankIndexEnd)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks)
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
//         {
//             banks[i]->pop();
//         }
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to get the front element of a specific bank
// template <typename T>
// T BankedFIFO<T>::front(size_t bankIndex) const
// {
//     if (bankIndex < numBanks && !banks[bankIndex].isEmpty())
//     {
//         return banks[bankIndex]->front();
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//         return T(); // Return a default-constructed value for error case
//     }
// }

// // Function to get the front elements of a series of banks
// template <typename T>
// std::vector<T> BankedFIFO<T>::front(size_t bankIndexStart, size_t bankIndexEnd)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks)
//     {
//         std::vector<T> values(bankIndexEnd - bankIndexStart, 0);
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
//         {
//             values[i - bankIndexStart] = banks[i]->front();
//         }
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to get the front elements of a series of banks with stride
// template <typename T>
// std::vector<T> BankedFIFO<T>::front(size_t bankIndexStart, size_t bankIndexEnd, size_t stride)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks)
//     {
//         std::vector<T> values((size_t)(bankIndexEnd - bankIndexStart) / stride, 0);
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
//         {
//             values[i - bankIndexStart] = banks[i]->front();
//         }
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//     }
// }

// // Function to check if a specific bank is empty
// template <typename T>
// bool BankedFIFO<T>::isEmpty(size_t bankIndex) const
// {
//     if (bankIndex < numBanks)
//     {
//         return banks[bankIndex].isEmpty();
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//         return true; // Assume the bank is empty for error case
//     }
// }

// // Function to get the size of a specific bank
// template <typename T>
// size_t BankedFIFO<T>::size(size_t bankIndex) const
// {
//     if (bankIndex < numBanks)
//     {
//         return banks[bankIndex].size();
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index.\n";
//         return 0; // Assume size is 0 for error case
//     }
// }

// template <typename T>
// void BankedFIFO<T>::setNumBanks(size_t n)
// {
//     numBanks = n;
// }

// template <typename T>
// void BankedFIFO<T>::setCapacityPerBank(size_t c)
// {
//     capacityPerBank = c;
// }

// template <typename T>
// size_t BankedFIFO<T>::getNumBanks()
// {
//     return numBanks;
// }

// template <typename T>
// size_t BankedFIFO<T>::getCapacityPerBank()
// {
//     return capacityPerBank;
// }
