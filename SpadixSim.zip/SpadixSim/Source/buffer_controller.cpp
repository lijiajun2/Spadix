#include "..\\Header\\buffer_controller.h"

// template <typename T>
// BUFFER_CONTROLLER<T>::BUFFER_CONTROLLER(size_t _height, size_t _width){
//     // inports_buffer2pu.resize(height, 0);
//     // inports_pu2buffer.resize(height, 0);
//     // outports_buffer2pu.resize(height, 0);
//     // outports_pu2buffer.resize(height, 0);
//     // for(int i=0; i<height; i++){
//     //     inports_buffer2pu.resize(width);
//     //     inports_pu2buffer.resize(width);
//     //     outports_buffer2pu.resize(width);
//     //     outports_pu2buffer.resize(width);
//     // }
//     height=_height;
//     width=_width;
// }

// template <typename T>
// void BUFFER_CONTROLLER<T>::Buffer2PU(SRAM<T> sram, PU<T> pu, size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address){
//     //read data from SRAM
//     std::vector<T> data=sram.read(bankIndexStart, bankIndexEnd, stride, address);

//     //forward the data to the PU
//     for(int i=0; i<height; i++){
//         for(int j=0; j<width; j++){
//             pu.inports[i][j]=data[i*width+j];
//         }
//     }
// }


// template <typename T>
// void BUFFER_CONTROLLER<T>::PU2Buffer(SRAM<T> sram, PU<T> pu, size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address){
//     //read the data from SRAM
//     std::vector<T> data;
//     for(int i=0; i<height; i++){
//         for(int j=0; j<width; j++){
//             data.push_back(pu.outports[i][j]);
//         }
//     }

//     //forwad the data to the SRAM
//     sram.write(bankIndexStart, bankIndexEnd, stride, address, data);
// }
