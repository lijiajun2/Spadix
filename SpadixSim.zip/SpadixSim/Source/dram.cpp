#include "..\\Header\\dram.h"

// template <typename T>
// void DRAM<T>::initialize(std::string filepath){
//     std::ifstream ifs(filepath);
//     if(ifs.is_open()){
//         T value;
//         // Read numbers from the file and store them in the vector
//         while (ifs >> value) {
//             this.data.push_back(value);
//         }

//         // Close the file
//         ifs.close();

//     } else {
//         // Display an error message if the file cannot be opened
//         std::cout << "Error: Unable to open file " << filepath << std::endl;
//     }
// }