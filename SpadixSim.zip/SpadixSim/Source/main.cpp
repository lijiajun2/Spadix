#include "..\\Header\\pe.h"
#include "..\\Header\\fifo.h"
#include "..\\Header\\config.h"
#include "..\\Header\\pu.h"
#include "..\\Header\\ram.h"
#include "..\\Header\\sram.h"
#include "..\\Header\\dram.h"
#include "..\\Header\\spadix.h"
#include "..\\Header\\sim.h"
#include "..\\Header\\buffer_controller.h"
#include "..\\Header\\pde.h"
#include <iostream>
#include <string>




int testFifo(){
    FIFO<float> fifo1(8);
    size_t a=8, b=8;
    BankedFIFO<float> my_banked_fifo(a,b);

    fifo1.push(1);
    fifo1.push(2);
    fifo1.pop();
    float c=fifo1.front();

    my_banked_fifo.push(0,1);
    my_banked_fifo.push(0,1);    
    return 0;
}

int testPE(){

    float _wz;
    float _wx;
    float _wy;

    PE<float>* pe0= new PE<float>(0.5,0.5,0.5,3,2,1);
    pe0->compute(0,0,0,0);
    pe0->compute(0,0,0,0);
    return 0;
}

int testPU(){
    PU<float> pu1(8,8);
    pu1.compute();
    return 0;
}

int testRam(){
    RAM<float> myRAM(10);

    // Write data to specific memory addresses
    myRAM.write(0, 42);
    myRAM.write(3, 99);

    // Read data from specific memory addresses
    float data1 = myRAM.read(0);
    float data2 = myRAM.read(3);

    BankedRAM<float> myBankedRam(10,16);
    myBankedRam.write(0,0, 1);
    std::vector<float> data(10, 2.0);
    myBankedRam.write(0, 10, 1, data);
    myBankedRam.write(0, 10, 2, 2, data);

    return 0;
}

int testDram(){
    DRAM<float> dram(1000);
    std::string dram_filepath="..\\Data\\dram.txt";
    dram.initialize(dram_filepath);
    return 0;
}

int testSram(){
    SRAM<float> mySRAM(10, 16);
    mySRAM.write(0,0, 1);
    std::vector<float> data(10, 2.0);
    mySRAM.write(0, 10, 1, data);
    mySRAM.write(0, 10, 2, 2, data);
    mySRAM.updateTotalEnergy();
    mySRAM.read(0, 1);
    mySRAM.read(0,10, 0);
    mySRAM.read(0, 10, 2, 1);
    return 0;
}



int main(){
    //testFifo();
    // testPE();
    //testSram();
    //testDram();

    SPADIX<float>* spadix=new SPADIX<float>(16, 8, 4, 4);
    PDE* pde=new PDE(10, 10, 100, 0.167, 0.167, 0.167);
    std::string dram_filepath="..\\Data\\dram.txt";
    //Initialize DRAM
    DRAM<float>* dram=new DRAM<float>(DRAM_CAPACITY);
    dram->initialize(dram_filepath);

    sim<float>(spadix, pde, dram);

    std::cout<<"Total cycle number: "<<NUM_CYCLES<<std::endl;

    return 0;
}