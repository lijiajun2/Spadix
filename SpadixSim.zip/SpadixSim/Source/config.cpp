/*
 * configuration
 *
 * Configuration of the accelerator
 */

#include "..\\Header\\config.h"

//********************************
//Architecture parameters
//********************************
// 16 bits in default
size_t DATA_WIDTH=16; 

// the scale of the PE array
size_t PU_NROW=8, PU_NCOL=8;
size_t SRAM_BANK=64;
size_t SRAM_ENTRY=64;
size_t HALO_FIFO_ENTRY=64;
size_t PSUM_FIFO_ENTRY=64;



//********************************
//Hardware parameters
//********************************
// the dram and sram bandwidth
long long DRAM_BANDWIDTH=(1LL)<<36;
long long SRAM_BANDWIDTH=(1LL)<<34;

long long CLOCK_RATE=(1<<30);
size_t DRAM_SETUP_LATENCY=100;

float SRAM_READ_ENERGY_PER_BYTE=0.1;
float SRAM_WRITE_ENERGY_PER_BYTE=0.1;
float DRAM_READ_ENERGY_PER_BYTE=10;
float DRAM_WRITE_ENERGY_PER_BYTE=10;
float DRAM_ENERGY_PER_SETUP=10;

size_t DRAM_CAPACITY=(1LL)<<20;



