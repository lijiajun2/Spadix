#include "..\\Header\\sram.h"

// // Function to write data to a specific bank and address
// template <typename T>
// void SRAM<T>::write(size_t bankIndex, size_t address, const T &data)
// {
//     if (bankIndex < numBanks && address < bankSize)
//     {
//         banks[bankIndex][address] = data;
//         // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
//         write_energy += sizeof(T) * write_energy_per_byte;
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for write operation.\n";
//     }
// }

// // Function to write data to sequential banks and a specific address
// template <typename T>
// void SRAM<T>::write(size_t bankIndexStart, size_t bankIndexEnd, size_t address, const std::vector<T> &data)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
//         {
//             banks[i][address] = data[i - bankIndexStart];
//             write_energy += sizeof(T) * write_energy_per_byte;
//         }
//         // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for write operation.\n";
//     }
// }

// // Function to write data to sequential banks and a specific address
// template <typename T>
// void SRAM<T>::write(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address, const std::vector<T> &data)
// {
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
//         {
//             banks[i][address] = data[(i - bankIndexStart) / stride];
//             write_energy += sizeof(T) * write_energy_per_byte;
//         }
//         // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for write operation.\n";
//     }
// }

// // Function to read data from a specific bank and address
// template <typename T>
// T SRAM<T>::read(size_t bankIndex, size_t address)
// {
//     if (bankIndex < numBanks && address < bankSize)
//     {
//         // std::cout << "Read: Bank[" << bankIndex << "][" << address << "] = " << banks[bankIndex][address] << std::endl;
//         read_energy += sizeof(T) * read_energy_per_byte;

//         // update the output ports of the sram
//         std::fill(outports.begin(), outports.end(), 0);
//         outports[bankIndex] = banks[bankIndex][address];

//         return banks[bankIndex][address];
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for read operation.\n";
//         return T(); // Return a default-constructed value for error case
//     }
// }

// // Function to write data to sequential banks and a specific address
// template <typename T>
// std::vector<T> SRAM<T>::read(size_t bankIndexStart, size_t bankIndexEnd, size_t address)
// {
//     std::vector<T> data;
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
//     {
//         // update the output ports of the sram
//         std::fill(outports.begin(), outports.end(), 0);

//         for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
//         {
//             read_energy += sizeof(T) * read_energy_per_byte;
//             outports[i] = banks[i][address];
//             data.push_back(banks[i][address]);
//         }

//         return data;
//         // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for write operation.\n";
//     }
// }

// // Function to write data to sequential banks and a specific address
// template <typename T>
// std::vector<T> SRAM<T>::read(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address)
// {
//     std::vector<T> data;
//     // update the output ports of the sram
//     std::fill(outports.begin(), outports.end(), 0);
//     if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
//     {
//         for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
//         {
//             read_energy += sizeof(T) * read_energy_per_byte;
//             outports[i] = banks[i][address];
//             data.push_back(banks[i][address]);
//         }
//         return data;
//         // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
//     }
//     else
//     {
//         std::cerr << "Error: Invalid bank index or address for write operation.\n";
//     }
// }

// template <typename T>
// void SRAM<T>::updateTotalEnergy()
// {
//     total_energy = write_energy + read_energy;
// }