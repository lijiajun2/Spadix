//*********************************************************
// Class of PU
// Each PU consists of multiple PEs organized as a 2D mesh
// the scale of the PU is height*width
//*********************************************************

#ifndef _PU_H
#define _PU_H

#include "pe.h"
#include "config.h"
#include "fifo.h"
#include <vector>

template <typename T>
class PU
{
public:
    // constructor
    PU(size_t height, size_t width);

    // destructor
    ~PU() {}

    // perform the computation in the PE array
    void compute();

    // synchronize the data between the PEs
    void interCommunicateFetch();

    void interCommunicateWriteBack();

    void haloCompute();

    // //prepare data for each PE from buffers or other PEs
    // void peFetchData();

    // //forward the result in each PE to buffers or other PEs
    // void peStoreData();

    // void writeBackData();
    // void fetchData();

    // scale of the PE array
    size_t height;
    size_t width;

    // a PU consists of multiple PEs
    std::vector<std::vector<PE<T> *>> pe_array;

    // a PU consists of a haloFIFO
    BankedFIFO<T> *halo_fifo;

    // a PU consists of a psumFIFO
    BankedFIFO<T> *psum_fifo;

    std::vector<std::vector<T>> outports;
    std::vector<std::vector<T>> inports;

    size_t count_multiplication;
    size_t count_addition;
    size_t count_reg_read;
    size_t count_reg_write;
};

template <typename T>
PU<T>::PU(size_t _height, size_t _width)
{
    height = _height;
    width = _width;

    // initialize the pe array, each PU is equipped with nrow*width PEs
    pe_array.resize(height);
    for (int i = 0; i < width; i++)
    {
        pe_array[i].resize(width);
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            pe_array[i][j] = new PE<T>();
        }
    }

    // initialize the haloFifo
    // the number of banks (numBanks) equals to height
    // the number of entries (capacityPerBank) is defined as HALO_FIFO_ENTRY, in config.h, it is an important design parameter
    halo_fifo = new BankedFIFO<T>(height, HALO_FIFO_ENTRY);
    // halo_fifo.setCapacityPerBank(HALO_FIFO_ENTRY);
    // halo_fifo.setNumBanks(height);
    // halo_fifo.banks.resize(halo_fifo.numBanks);
    // for(int i=0; i<height; i++){
    //     halo_fifo.banks[i].resize(halo_fifo.capacityPerBank);
    // }

    // initialize the psumFifo
    // the number of banks (numBanks) equals to height
    // the number of entries (capacityPerBank) is defined as PSUM_FIFO_ENTRY, in config.h, it is an important design parameter
    psum_fifo = new BankedFIFO<T>(height, PSUM_FIFO_ENTRY);
    // psum_fifo.setCapacityPerBank(PSUM_FIFO_ENTRY);
    // psum_fifo.setNumBanks(height);
    // psum_fifo.banks.resize(psum_fifo.numBanks);
    // for(int i=0; i<height; i++){
    //     psum_fifo.banks[i].resize(psum_fifo.capacityPerBank);
    // }

    inports.resize(height);
    for (int i = 0; i < height; i++)
    {
        inports[i].resize(width);
    }
    outports.resize(height);
    for (int i = 0; i < height; i++)
    {
        outports[i].resize(width);
    }

    count_multiplication=0;
    count_addition=0;
    count_reg_read=0;
    count_reg_write=0;
}

// prepare data for each pe
template <typename T>
void PU<T>::interCommunicateFetch()
{
    // update the output ports for PU

    // assign the grid values from up
    for (int i = 1; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            pe_array[i][j]->inport_wire_pe_up = pe_array[i - 1][j]->outport_wire_pe_down;
        }
    }
    for (int j = 0; j < width; j++)
    {
        pe_array[0][j]->inport_wire_pe_up = 0;
    }

    // assign the grid values from down
    for (int i = 0; i < height - 1; i++)
    {
        for (int j = 0; j < width; j++)
        {
            pe_array[i][j]->inport_wire_pe_down = pe_array[i + 1][j]->outport_wire_pe_up;
        }
    }
    for (int j = 0; j < width; j++)
    {
        pe_array[height - 1][j]->inport_wire_pe_down = 0;
    }

    // assign the grid values from left
    for (int i = 0; i < height; i++)
    {
        for (int j = 1; j < width; j++)
        {
            pe_array[i][j]->inport_wire_pe_left = pe_array[i][j - 1]->outport_wire_pe_right;
        }
    }
    // for the leftmost PEs, the left grid values are from halo_fifo
    std::vector<T> halo = halo_fifo->front(0, height);
    for (int i = 0; i < height; i++)
    {
        pe_array[i][0]->inport_wire_pe_left = halo[i];
    }

    // assign the grid values from right
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width - 1; j++)
        {
            pe_array[i][j]->inport_wire_pe_right = pe_array[i][j + 1]->outport_wire_pe_left;
        }
    }
    // for the rightmost PEs, the right grid values are missing
    for (int i = 0; i < height; i++)
    {
        pe_array[i][width - 1]->inport_wire_pe_right = 0;
    }

    // synchronize the data in fifos
}

// template <typename T>
// void PU<T>::fetchData(){

// }

// template<typename T>
// void PU<T>::writeBackData(){
//     // for each PE, forward the result to sram or psum-fifo
//     for(int i=0; i<this->height; i++){
//         for(int j=0; j<this->width-1; j++){

//         }
//     }

//     for(int i=0; i<this->height; i++){
//         psum_fifo->banks[i].push(i, pe_array[i][j]->reg_out);
//     }
// }

// the computation process of the PU, each pe performs the computation individually
template <typename T>
void PU<T>::compute()
{
    // update the input ports for each PE
    for (int i = 0; i < this->height; i++)
    {
        for (int j = 0; j < this->width; j++)
        {
            pe_array[i][j]->inport_reg_z = this->inports[i][j];
        }
    }

    // perform the computation in each PE
    for (int i = 0; i < this->height; i++)
    {
        for (int j = 0; j < this->width; j++)
        {
            pe_array[i][j]->compute(0, 0, 0, 0);
            count_multiplication+=pe_array[i][j]->num_multiplication;
            count_addition+=pe_array[i][j]->num_multiplication;
            count_reg_read+=pe_array[i][j]->num_reg_read;
            count_reg_write+=pe_array[i][j]->num_reg_write;
        }
    }
}

// write back data for each pe
template <typename T>
void PU<T>::interCommunicateWriteBack()
{
    // update the output ports for PU

    // update the input ports for each PE
    for (int i = 0; i < this->height; i++)
    {
        for (int j = 0; j < this->width; j++)
        {
            this->outports[i][j] = pe_array[i][j]->outport_wire_partial_sum;
        }
    }

    // for the rightmost PEs, no right neighbor PEs, the grid values are pushed into halo_fifo
    std::vector<T> halo(height, 0);
    for (int i = 0; i < height; i++)
    {
        halo[i] = pe_array[i][width - 1]->outport_wire_pe_right;
    }
    halo_fifo->push(0, height, halo);

    // for the rightmost PEs, the partial sums are pushed into psum_fifo
    std::vector<T> psum(height, 0);
    for (int i = 0; i < height; i++)
    {
        psum[i] = pe_array[i][width - 1]->outport_wire_partial_sum;
    }
    psum_fifo->push(0, height, psum);

    // synchronize the data in fifos
}

template <typename T>
void PU<T>::haloCompute()
{
    // perform the halo partial sums computation
    // update the output ports of the pe array

    std::vector<T> psum(height, 0);
    psum = psum_fifo->front(0, height);
    for (int i = 0; i < height; i++)
    {
        psum[i] += pe_array[i][0]->outport_wire_pe_left;
    }

    // update the halo psum values
    for (int i = 0; i < height; i++)
    {
        this->outports[i][0] = psum[i];
    }
}

#endif