#ifndef _PDE_H
#define _PDE_H

#include <stdlib.h>
class PDE
{
public:
    PDE(size_t _h, size_t _w, size_t _d, float _x, float _y, float _z):height(_h), width(_w), depth(_d), wx(_x), wy(_y), wz(_z){}
    ~PDE(){}

    size_t height; // the size of the PDE problem
    size_t width;
    size_t depth;

private:
    float wx;
    float wy;
    float wz;
};

#endif