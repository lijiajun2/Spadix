#ifndef _SIM_H
#define _SIM_H

#include "spadix.h"
#include "pde.h"
#include "config.h"
#include <string>
#include <algorithm>

//Evaluation Metrics
extern size_t NUM_CYCLES=0;
extern size_t NUM_RF_READ=0;
extern size_t NUM_RF_WRITE=0;
extern size_t NUM_SRAM_READ=0;
extern size_t NUM_SRAM_WRITE=0;
extern size_t NUM_DRAM_READ=0;
extern size_t NUM_DRAM_WRITE=0;



//The simulation flow

template <typename T>
void sim(SPADIX<T> *spadix, PDE *pde, DRAM<T>* dram)
{

    // //Intialize the evaluation metrics
    // NUM_CYCLES=0;
    // NUM_RF_READ=0;
    // NUM_RF_WRITE=0;
    // NUM_SRAM_READ=0;
    // NUM_SRAM_WRITE=0;
    // NUM_DRAM_READ=0;
    // NUM_DRAM_WRITE=0;



    std::vector<T> plane;
    for (int d = 0; d < pde->depth; d += spadix->bankSize)
    {
        for (int h = 0; h < pde->height; h += spadix->heightPU)
        {
            for (int w = 0; w < pde->width; w += spadix->widthPU)
            {

                size_t cycle_off_chip_communication=0;
                size_t cycle_computation=0;
                size_t data_read_dram=0;

                // Off-chip communication, DMA stage, fetch data from DRAM to SRAM
                for (int dd = d; dd < std::min(pde->depth, d + spadix->bankSize); dd++)
                {
                    std::vector<T> plane;
                    for (int hh = h; hh < std::min(pde->height, h + spadix->heightPU); hh++)
                    {
                        for (int ww = w; ww < std::min(pde->width, w + spadix->widthPU); ww++)
                        {
                            plane.push_back(dram->data[dd * pde->width * pde->height + ww * pde->height + hh]);
                            data_read_dram++;
                            dram->num_read++;
                        }
                    }
                    dram->num_setup++;

                    //calculate the required cycles of the stage of the off-chip communication
                    cycle_off_chip_communication+=DRAM_SETUP_LATENCY+CLOCK_RATE*(data_read_dram*sizeof(T)/DRAM_BANDWIDTH);

                    spadix->sram->write(0, spadix->sram->numBanks, 1, dd - d, plane);
                }

                // On-chip computation
                cycle_computation=spadix->compute(0, std::min(pde->depth, d + spadix->bankSize)-d);

                // Off-chip communication, DMA stage, write back to DRAM
                for (int dd = d; dd < std::min(pde->depth, d + spadix->bankSize); dd++)
                {
                    std::vector<T> plane = spadix->sram->read(0, spadix->sram->numBanks, 1, dd - d);
                    for (int hh = h; hh < std::min(pde->height, h + spadix->heightPU); hh++)
                    {
                        for (int ww = w; ww < std::min(pde->width, w + spadix->widthPU); ww++)
                        {
                            dram->data[dd * pde->width * pde->height + ww * pde->height + hh] = plane[(hh - h) * spadix->widthPU + ww];
                            dram->num_write++;
                        }
                    }
                    dram->num_setup++;
                }


                //update the required cycles
                NUM_CYCLES+=std::max(cycle_computation, cycle_off_chip_communication);

                std::cout<<"Current cycle:"<<NUM_CYCLES;
                std::cout<<", h:"<<h<<", w:"<<w<<",d:"<<d<<std::endl;
            }
        }
    }
        dram->updateTotalEnergy();
        spadix->sram->updateTotalEnergy();
}

#endif