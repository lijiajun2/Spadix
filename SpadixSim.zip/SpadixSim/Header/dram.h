#ifndef _DRAM_H
#define _DRAM_H

#include <vector>
#include <fstream>
#include <iostream>
#include "config.h"

template <typename T>
class DRAM
{
public:
    DRAM(size_t _capacity) : capacity(_capacity)
    {
        per_setup_energy = DRAM_ENERGY_PER_SETUP;
        setup_energy = 0;
        read_energy_per_byte = DRAM_READ_ENERGY_PER_BYTE;
        read_energy = 0;
        write_energy_per_byte = DRAM_WRITE_ENERGY_PER_BYTE;
        write_energy = 0;
        num_setup=0;
        num_read=0;
        num_write=0;
        total_energy = 0;        
    }
    ~DRAM() {}

    void initialize(std::string); // initialize the dram using a file

    void updateTotalEnergy();

    float per_setup_energy;
    float setup_energy;
    float read_energy_per_byte;
    float read_energy;
    float write_energy_per_byte;
    float write_energy;
    float num_read;
    float num_write;
    float num_setup;
    float total_energy;

    size_t capacity;
    std::vector<T> data; //
};

template <typename T>
void DRAM<T>::initialize(std::string filepath)
{
    std::ifstream ifs(filepath);
    if (ifs.is_open())
    {
        T value;
        // Read numbers from the file and store them in the vector
        while (ifs >> value)
        {
            this->data.push_back(value);
        }

        // Close the file
        ifs.close();
    }
    else
    {
        // Display an error message if the file cannot be opened
        std::cout << "Error: Unable to open file " << filepath << std::endl;
    }
}

template <typename T>
void DRAM<T>::updateTotalEnergy()
{
    read_energy=num_read*read_energy_per_byte*sizeof(T);
    write_energy=num_write*write_energy_per_byte*sizeof(T);
    setup_energy=num_setup*per_setup_energy;
    total_energy = write_energy + read_energy +setup_energy;
}


#endif