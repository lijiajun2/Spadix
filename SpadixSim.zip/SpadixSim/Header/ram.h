//*********************************************************
// Class of RAM
// to temporarily store the data
//*********************************************************

#ifndef _RAM_H
#define _RAM_H

#include "config.h"
#include <vector>
#include <iostream>

template <typename T>
class RAM
{
public:
    // Constructor to initialize the size of the RAM
    explicit RAM(size_t size) : memory(size, T()) {}

    // Destructor
    ~RAM() {}

    // Function to write data to a specific memory address
    void write(size_t address, const T &data)
    {
        if (address < memory.size())
        {
            memory[address] = data;
        }
        else
        {
            std::cerr << "Error: Invalid memory address for write operation.\n";
        }
    }

    // Function to read data from a specific memory address
    T read(size_t address) const
    {
        if (address < memory.size())
        {
            return memory[address];
        }
        else
        {
            std::cerr << "Error: Invalid memory address for read operation.\n";
            return T(); // Return a default-constructed value for error case
        }
    }

private:
    std::vector<T> memory;
};

template <typename T>
class BankedRAM
{
public:
    // Constructor to initialize the number of banks and the size of each bank
    BankedRAM(size_t numBanks, size_t bankSize) : numBanks(numBanks), bankSize(bankSize)
    {
        banks.resize(numBanks, std::vector<T>(bankSize, T()));
    }

    // Destructor
    ~BankedRAM() {}

    // Function to write data to a specific bank and address
    void write(size_t bankIndex, size_t address, const T &data)
    {
        if (bankIndex < numBanks && address < bankSize)
        {
            banks[bankIndex][address] = data;
            // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for write operation.\n";
        }
    }

    // Function to write data to sequential banks and a specific address
    void write(size_t bankIndexStart, size_t banIndexEnd, size_t address, const std::vector<T> &data)
    {
        if (bankIndexStart < banIndexEnd && banIndexEnd <= numBanks && address < bankSize)
        {
            for (size_t i = bankIndexStart; i < banIndexEnd; i++)
            {
                banks[i][address] = data[i - bankIndexStart];
            }
            // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for write operation.\n";
        }
    }

    // Function to write data to sequential banks and a specific address
    void write(size_t bankIndexStart, size_t banIndexEnd, size_t stride, size_t address, const std::vector<T> &data)
    {
        if (bankIndexStart < banIndexEnd && banIndexEnd <= numBanks && address < bankSize)
        {
            for (size_t i = bankIndexStart; i < banIndexEnd; i += stride)
            {
                banks[i][address] = data[(i - bankIndexStart) / stride];
            }
            // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for write operation.\n";
        }
    }

    // Function to read data from a specific bank and address
    T read(size_t bankIndex, size_t address)
    {
        if (bankIndex < numBanks && address < bankSize)
        {
            // std::cout << "Read: Bank[" << bankIndex << "][" << address << "] = " << banks[bankIndex][address] << std::endl;
            return banks[bankIndex][address];
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for read operation.\n";
            return T(); // Return a default-constructed value for error case
        }
    }

    // Function to write data to sequential banks and a specific address
    std::vector<T> read(size_t bankIndexStart, size_t banIndexEnd, size_t address)
    {
        std::vector<T> data;
        if (bankIndexStart < banIndexEnd && banIndexEnd <= numBanks && address < bankSize)
        {
            for (size_t i = bankIndexStart; i < banIndexEnd; i++)
            {
                data.push_back(banks[i][address]);
            }
            // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for write operation.\n";
        }
    }

    // Function to write data to sequential banks and a specific address
    std::vector<T> read(size_t bankIndexStart, size_t banIndexEnd, size_t stride, size_t address)
    {
        std::vector<T> data;
        if (bankIndexStart < banIndexEnd && banIndexEnd <= numBanks && address < bankSize)
        {
            for (size_t i = bankIndexStart; i < banIndexEnd; i += stride)
            {
                data.push_back(banks[i][address]);
            }
            // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        }
        else
        {
            std::cerr << "Error: Invalid bank index or address for write operation.\n";
        }
    }

private:
    size_t numBanks;                   // Number of banks
    size_t bankSize;                   // Size of each bank
    std::vector<std::vector<T>> banks; // Vector of banks, each containing a vector of memory cells
};

#endif