#ifndef _PE_H
#define _PE_H

#include "config.h"

template <typename T>
class PE
{
public:
    // constructor
    PE();
    PE(T _wx, T _wy, T _wz);
    PE(T _wx, T _wy, T _wz, T _reg_z_1, T _reg_z_2, T _reg_out);

    // destructor
    ~PE(){};
    void compute(bool control_mux0, bool control_mux1, bool control_mux2, bool control_demux);

    // input ports
    T inport_reg_z;
    T inport_wire_pe_up;
    T inport_wire_buffer_up;
    T inport_wire_pe_left;
    T inport_wire_pe_right;
    T inport_wire_buffer_down;
    T inport_wire_pe_down;

    // output ports
    T outport_wire_pe_up;
    T outport_wire_pe_left;
    T outport_wire_pe_down;
    T outport_wire_pe_right;
    T outport_wire_partial_sum;
    
    size_t num_multiplication;
    size_t num_addition;
    size_t num_reg_read;
    size_t num_reg_write;


private:
    // registers in PE
    T reg_z_1;
    T reg_z_2;
    T wz;
    T wx;
    T wy;
    T reg_out;
};

template <typename T>
PE<T>::PE()
{
    reg_z_1 = 0;
    reg_z_2 = 0;
    wz = 0;
    wx = 0;
    wy = 0;
    reg_out = 0;

    inport_reg_z = 0;            // port 0
    inport_wire_pe_up = 0;       // port 1
    inport_wire_buffer_up = 0;   // port 2
    inport_wire_pe_left = 0;     // port 3
    inport_wire_pe_right = 0;    // port 4
    inport_wire_buffer_down = 0; // port 5
    inport_wire_pe_down;         // port 6

    outport_wire_pe_up = 0;       // port 7
    outport_wire_pe_left = 0;     // port 8
    outport_wire_pe_down = 0;     // port 9
    outport_wire_pe_right = 0;    // port 10
    outport_wire_partial_sum = 0; // port 11

    num_multiplication=3;
    num_addition=4;
    num_reg_read=8;
    num_reg_write=3;
}

template <typename T>
PE<T>::PE(T _wx, T _wy, T _wz)
{
    wx = _wx;
    wy = _wy;
    wz = _wz;
    reg_z_1 = 0;
    reg_z_2 = 0;
    reg_out = 0;

    inport_reg_z = 0;            // port 0
    inport_wire_pe_up = 0;       // port 1
    inport_wire_buffer_up = 0;   // port 2
    inport_wire_pe_left = 0;     // port 3
    inport_wire_pe_right = 0;    // port 4
    inport_wire_buffer_down = 0; // port 5
    inport_wire_pe_down = 0;     // port 6

    outport_wire_pe_up = 0;       // port 7
    outport_wire_pe_left = 0;     // port 8
    outport_wire_pe_down = 0;     // port 9
    outport_wire_pe_right = 0;    // port 10
    outport_wire_partial_sum = 0; // port 11

    num_multiplication=3;
    num_addition=4;
    num_reg_read=8;
    num_reg_write=3;
}

template <typename T>
PE<T>::PE(T _wx, T _wy, T _wz, T _reg_z_1, T _reg_z_2, T _reg_out)
{
    wx = _wx;
    wy = _wy;
    wz = _wz;
    reg_z_1 = _reg_z_1;
    reg_z_2 = _reg_z_2;
    reg_out = _reg_out;

    inport_reg_z = 0;            // port 0
    inport_wire_pe_up = 0;       // port 1
    inport_wire_buffer_up = 0;   // port 2
    inport_wire_pe_left = 0;     // port 3
    inport_wire_pe_right = 0;    // port 4
    inport_wire_buffer_down = 0; // port 5
    inport_wire_pe_down;         // port 6

    outport_wire_pe_up = 0;       // port 7
    outport_wire_pe_left = 0;     // port 8
    outport_wire_pe_down = 0;     // port 9
    outport_wire_pe_right = 0;    // port 10
    outport_wire_partial_sum = 0; // port 11
}

template <typename T>
void PE<T>::compute(bool control_mux0, bool control_mux1, bool control_mux2, bool control_demux)
{
    // assign the values of the grid nodes
    T grid_y_up = control_mux0 ? inport_wire_pe_up : inport_wire_buffer_up;       // grid node from upper pe or buffer
    T grid_x = control_mux1 ? inport_wire_pe_left : inport_wire_pe_right;         // grid node from left or right pe
    T grid_y_down = control_mux2 ? inport_wire_pe_down : inport_wire_buffer_down; // grid node from upper pe or buffer
    T grid_z = this->inport_reg_z;

    // start the kernel computation
    this->reg_out = (grid_z + this->reg_z_2) * this->wz + (grid_x + this->reg_z_1) * wx + (grid_y_up + grid_y_down) * wy;

    // assign the values of the output wires
    this->outport_wire_partial_sum = this->reg_out;
    this->outport_wire_pe_up = this->reg_z_1;
    this->outport_wire_pe_down = this->reg_z_1;
    // this->outport_wire_pe_left=control_demux? this->reg_z_1:0;
    // this->outport_wire_pe_right=control_demux? 0:this->reg_z_1;
    this->outport_wire_pe_left = control_demux ? this->reg_z_1 : this->reg_z_1;
    this->outport_wire_pe_right = control_demux ? this->reg_z_1 : this->reg_z_1;

    // update the values of the registers
    this->reg_z_2 = this->reg_z_1;
    this->reg_z_1 = this->inport_reg_z;
}

#endif