//*********************************************************
// Configure the hyperparameters of the accelerator
// - the data width
// - the scale of the pe array, nrow, ncol
// - dram bandwidth 
// - sram banks, entries, sram bandwidth 
// - clock rate 
//*********************************************************

#ifndef _CONFIGURATION_H
#define _CONFIGURATION_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


// 16 bits in default
extern size_t DATA_WIDTH; 

// the scale of the PE array
extern size_t PU_NROW, PU_NCOL;

// the dram and sram bandwidth
extern long long DRAM_BANDWIDTH, SRAM_BANDWIDTH;

extern size_t DRAM_CAPACITY;

extern size_t SRAM_BANK, SRAM_ENTRY;

extern size_t HALO_FIFO_ENTRY, PSUM_FIFO_ENTRY;

// the clock rate
extern long long CLOCK_RATE;

// the set up latency of DRAM access
extern size_t DRAM_SETUP_LATENCY;

extern float SRAM_READ_ENERGY_PER_BYTE;
extern float SRAM_WRITE_ENERGY_PER_BYTE;
extern float DRAM_READ_ENERGY_PER_BYTE;
extern float DRAM_WRITE_ENERGY_PER_BYTE;
extern float DRAM_ENERGY_PER_SETUP;

#endif
