//*********************************************************
// Class of Spadix
// Spadix consists of a PU, SRAM buffers, a buffer controller
//*********************************************************

#ifndef _SPADIX_H
#define _SPADIX_H

#include "pe.h"
#include "config.h"
#include "fifo.h"
#include "pu.h"
#include "buffer_controller.h"
#include <vector>

template <typename T>
class SPADIX
{
public:
    SPADIX(size_t _numBanks, size_t _bankSize, size_t _heightPU, size_t _widthPU) : numBanks(_numBanks), bankSize(_bankSize), heightPU(_heightPU), widthPU(_widthPU)
    {
        sram = new SRAM<T>(numBanks, bankSize);
        pu = new PU<T>(heightPU, widthPU);
        buffer_controller= new BUFFER_CONTROLLER<T>(heightPU, widthPU);
    }
    ~SPADIX() {}

    size_t compute();
    size_t compute(size_t entryIndexStart, size_t entryIndexEnd);


    SRAM<T> *sram;
    BUFFER_CONTROLLER<T> *buffer_controller;
    PU<T> *pu;

    // parameters of the sram
    size_t numBanks; // Number of banks
    size_t bankSize; // Size of each bank

    // parameters of the PU
    size_t heightPU;
    size_t widthPU;
};


template <typename T>
size_t SPADIX<T>::compute(){
    for(size_t d=0; d<bankSize; d++){
        buffer_controller->Buffer2PU(sram, pu, 0, numBanks, 1, d);
        pu->compute();
        buffer_controller->PU2Buffer(sram, pu, 0, numBanks, 1, d);
    }
    return bankSize;
}

template <typename T>
size_t SPADIX<T>::compute(size_t entryIndexStart, size_t entryIndexEnd){
    for(size_t d=entryIndexStart; d<entryIndexEnd; d++){
        buffer_controller->Buffer2PU(sram, pu, 0, numBanks, 1, d);
        pu->compute();
        buffer_controller->PU2Buffer(sram, pu, 0, numBanks, 1, d);
    }    
    return entryIndexEnd-entryIndexStart;
}

#endif