//*********************************************************
// Class of SRAM
// to temporarily store the data
//*********************************************************

#ifndef _SRAM_H
#define _SRAM_H

#include "ram.h"
#include "config.h"
#include <vector>
#include <iostream>

template <typename T>
class SRAM
{
public:
    // Constructor to initialize the number of banks and the size of each bank
    SRAM(size_t numBanks, size_t bankSize) : numBanks(numBanks), bankSize(bankSize), read_energy_per_byte(SRAM_READ_ENERGY_PER_BYTE), write_energy_per_byte(SRAM_WRITE_ENERGY_PER_BYTE), read_energy(0), write_energy(0), total_energy(0)
    {
        banks.resize(numBanks, std::vector<T>(bankSize, T()));
        inports.resize(numBanks, T());
        outports.resize(numBanks, T());
    }

    // Destructor
    ~SRAM() {}

    // Function to write data to a specific bank and address
    void write(size_t bankIndex, size_t address, const T &data);

    // Function to write data to sequential banks and a specific address
    void write(size_t bankIndexStart, size_t bankIndexEnd, size_t address, const std::vector<T> &data);
    // Function to write data to sequential banks and a specific address
    void write(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address, const std::vector<T> &data);

    // Function to read data from a specific bank and address
    T read(size_t bankIndex, size_t address);

    // Function to write data to sequential banks and a specific address
    std::vector<T> read(size_t bankIndexStart, size_t bankIndexEnd, size_t address);

    // Function to write data to sequential banks and a specific address
    std::vector<T> read(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address);

    void updateTotalEnergy();


    float read_energy_per_byte;
    float read_energy;
    float write_energy_per_byte;
    float write_energy;
    float total_energy;

    size_t numBanks;                   // Number of banks
    size_t bankSize;                   // Size of each bank
    std::vector<std::vector<T>> banks; // Vector of banks, each containing a vector of memory cells

    std::vector<T> inports;  // vector of data values for output
    std::vector<T> outports; // vector of data values for input
};

// Function to write data to a specific bank and address
template <typename T>
void SRAM<T>::write(size_t bankIndex, size_t address, const T &data)
{
    if (bankIndex < numBanks && address < bankSize)
    {
        banks[bankIndex][address] = data;
        // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
        write_energy += sizeof(T) * write_energy_per_byte;
    }
    else
    {
        std::cerr << "Error: Invalid bank index or address for write operation.\n";
    }
}

// Function to write data to sequential banks and a specific address
template <typename T>
void SRAM<T>::write(size_t bankIndexStart, size_t bankIndexEnd, size_t address, const std::vector<T> &data)
{
    if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
    {
        for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
        {
            banks[i][address] = data[i - bankIndexStart];
            write_energy += sizeof(T) * write_energy_per_byte;
        }
        // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
    }
    else
    {
        std::cerr << "Error: Invalid bank index or address for write operation.\n";
    }
}

// Function to write data to sequential banks and a specific address
template <typename T>
void SRAM<T>::write(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address, const std::vector<T> &data)
{
    if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
    {
        for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
        {
            banks[i][address] = data[(i - bankIndexStart) / stride];
            write_energy += sizeof(T) * write_energy_per_byte;
        }
        // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
    }
    else
    {
        //std::cerr << "Error: Invalid bank index or address for write operation.\n";
    }
}

// Function to read data from a specific bank and address
template <typename T>
T SRAM<T>::read(size_t bankIndex, size_t address)
{
    if (bankIndex < numBanks && address < bankSize)
    {
        // std::cout << "Read: Bank[" << bankIndex << "][" << address << "] = " << banks[bankIndex][address] << std::endl;
        read_energy += sizeof(T) * read_energy_per_byte;

        // update the output ports of the sram
        std::fill(outports.begin(), outports.end(), 0);
        outports[bankIndex] = banks[bankIndex][address];

        return banks[bankIndex][address];
    }
    else
    {
        std::cerr << "Error: Invalid bank index or address for read operation.\n";
        return T(); // Return a default-constructed value for error case
    }
}

// Function to write data to sequential banks and a specific address
template <typename T>
std::vector<T> SRAM<T>::read(size_t bankIndexStart, size_t bankIndexEnd, size_t address)
{
    std::vector<T> data;
    if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
    {
        // update the output ports of the sram
        std::fill(outports.begin(), outports.end(), 0);

        for (size_t i = bankIndexStart; i < bankIndexEnd; i++)
        {
            read_energy += sizeof(T) * read_energy_per_byte;
            outports[i] = banks[i][address];
            data.push_back(banks[i][address]);
        }

        return data;
        // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
    }
    else
    {
        std::cerr << "Error: Invalid bank index or address for write operation.\n";
    }
    return data;
}

// Function to write data to sequential banks and a specific address
template <typename T>
std::vector<T> SRAM<T>::read(size_t bankIndexStart, size_t bankIndexEnd, size_t stride, size_t address)
{
    std::vector<T> data;
    // update the output ports of the sram
    std::fill(outports.begin(), outports.end(), 0);
    if (bankIndexStart < bankIndexEnd && bankIndexEnd <= numBanks && address < bankSize)
    {
        for (size_t i = bankIndexStart; i < bankIndexEnd; i += stride)
        {
            read_energy += sizeof(T) * read_energy_per_byte;
            outports[i] = banks[i][address];
            data.push_back(banks[i][address]);
        }
        return data;
        // std::cout << "Write: Bank[" << bankIndex << "][" << address << "] = " << data << std::endl;
    }
    else
    {
        std::cerr << "Error: Invalid bank index or address for write operation.\n";
    }
    return data;
}

template <typename T>
void SRAM<T>::updateTotalEnergy()
{
    total_energy = write_energy + read_energy;
}

#endif